﻿using System;

namespace SharedLibrary
{
	public class Utilities
	{
		public string ConverNumber(int number)
		{
			return number.ToString();
		}
	}
}
